var slug_chars_msg =
  "slug 的內容只能事字母或者數字！（A-Z,0-9,- 與 _）";
var role_msg = "你必須替這個角色取個獨特的名字！";
var login_msg1 = "使用者名稱至少要 ";
var login_msg2 = " 個字元！";
var passwd_msg1 = "密碼至少要";
var passwd_msg2 = " 個字元！";
var passwd_match_msg = "密碼一定要匹配！";
var passwd_start_msg = "密碼開頭不能有空白！";
var passwd_end_msg = "密碼結尾不能有空白！";
var days_msg = "這個日期根本不存在！它已經被改為 ";
var data_msg =  "你必須將所有欄位都填上資料！";
var empty_field_msg = "你必須給定這個的值 ";
var illegal_chars_msg = " 內含非法字元！";
var warn_delete_msg = "You are about to permanently delete items! Do you wish to continue?"