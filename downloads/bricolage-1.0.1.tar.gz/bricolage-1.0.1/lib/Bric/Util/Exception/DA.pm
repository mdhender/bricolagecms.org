package Bric::Util::Exception::DA;

=head1 DESCRIPTION

stub package

=cut
