package Bric::Util::Exception::AP;

=head1 DESCRIPTION

stub package

=cut
