var slug_chars_msg =
  "The slug can only contain alphanumeric characters (A-Z, 0-9, - or _)!";
var role_msg = "You must supply a unique name for this role!";
var login_msg1 = "Usernames must be at least ";
var login_msg2 = " characters!";
var passwd_msg1 = "Passwords must be at least ";
var passwd_msg2 = " characters!";
var passwd_match_msg = "Passwords must match!";
var passwd_start_msg = "Passwords cannot have spaces at the beginning!";
var passwd_end_msg = "Passwords cannot have spaces at the end!"
var days_msg = "This day does not exist! Your day is changed to ";
var data_msg = "You must provide a value for all data field elements!";
var empty_field_msg = "You must supply a value for ";
var illegal_chars_msg = " contains illegal characters!";
var warn_delete_msg = "You are about to permanently delete items! Do you wish to continue?"