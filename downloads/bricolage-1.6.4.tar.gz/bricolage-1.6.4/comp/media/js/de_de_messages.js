// translated from revision 1.1 of en_us_messages.js
var slug_chars_msg =
  "Der Kurzname darf nur alphanumerische Zeichen (A-Z, 0-9, - oder _) enthalten!";
var role_msg = "Sie müssen einen eindeutigen Namen für diese Rolle angeben!";
var login_msg1 = "Benutzernamen müssen zumindest ";
var login_msg2 = " Zeichen lang sein!";
var passwd_msg1 = "Passwörter müssen zumindest ";
var passwd_msg2 = " Zeichen lang sein!";
var passwd_match_msg = "Die Passwörter müssen übereinstimmen!";
var passwd_start_msg = "Die Passwörter dürfen am Anfang kein Leerzeichen haben!";
var passwd_end_msg = "Die Passwörter dürfen am Ende keine Leerzeichen haben!"
var days_msg = "Dieser Tag existiert nicht! Ihr Tag wurde geändert, auf ";
var data_msg = "Sie müssen einen Wert für alle Datenfelder-Elemente angeben!";
var empty_field_msg = "Sie müssen einen Wert angeben, für ";
var illegal_chars_msg = " enthält illegale Zeichen!";
var warn_delete_msg = "You are about to permanently delete items! Do you wish to continue?"
