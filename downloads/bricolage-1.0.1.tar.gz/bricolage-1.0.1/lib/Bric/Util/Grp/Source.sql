-- Project: Bricolage
-- VERSION: $Revision: 1.1.1.1 $
--
-- $Date: 2001/09/06 21:55:58 $
-- Target DBMS: PostgreSQL 7.1.2
-- Author: David Wheeler <david@wheeler.net>
--

-- 
-- TABLE: source_member 
--

CREATE TABLE source_member (
    id          NUMERIC(10,0)  NOT NULL
                               DEFAULT NEXTVAL('seq_source_member'),
    object_id   NUMERIC(10,0)  NOT NULL,
    member__id  NUMERIC(10,0)  NOT NULL,
    CONSTRAINT pk_source_member__id PRIMARY KEY (id)
);

-- 
-- SEQUENCES.
--

CREATE SEQUENCE seq_source_member START 1024;

--
-- INDEXES.
--
CREATE INDEX fkx_source__source_member ON source_member(object_id);
CREATE INDEX fkx_member__source_member ON source_member(member__id);

/*
Change Log:
$Log: Source.sql,v $
Revision 1.1.1.1  2001/09/06 21:55:58  wheeler
Upload to SourceForge.

*/
