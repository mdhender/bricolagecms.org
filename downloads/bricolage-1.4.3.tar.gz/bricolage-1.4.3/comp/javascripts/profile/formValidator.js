<%args>

$id => undef

</%args>

<script language="javascript">

var requiredFields         = new Object();
var specialCharacterFields = new Object();

</script>
