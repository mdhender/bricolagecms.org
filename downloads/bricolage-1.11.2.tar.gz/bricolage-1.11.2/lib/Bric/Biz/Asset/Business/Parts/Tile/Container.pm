package Bric::Biz::Asset::Business::Parts::Tile::Container;

###############################################################################

=head1 Name

Bric::Biz::Asset::Business::Parts::Tile::Container - Deprecated; use Bric::Biz::Element::Container instead

=cut

require Bric; our $VERSION = Bric->VERSION;

=head1 Description

The functionality of this class has been moved to
L<Bric::Biz::Element::Container|Bric::Biz::Element::Container>. Please use
that class, instead.

=cut

use base 'Bric::Biz::Element::Container';

1;
__END__
