-- Project: Bricolage
-- VERSION: $Revision: 1.1.1.1 $
--
-- $Date: 2001/09/06 21:54:01 $
-- Target DBMS: PostgreSQL 7.1.2
-- Author: Garth Webb <garth@perijove.com>
--
-- The sql to create the element_data table.
-- This maps to the Bric::AssetType::Parts::Data class.
-- Related tables are element and element_container
--

-- -----------------------------------------------------------------------------
-- Sequences

-- Unique IDs for the element_data table
CREATE SEQUENCE seq_at_data START 1024;

-- Unique IDs for the attr_element_data table
CREATE SEQUENCE seq_attr_at_data START 1024;

-- Unique IDs for each attr_element_data_*_val table
CREATE SEQUENCE seq_attr_at_data_val START 1024;

-- Unique IDs for the element_data_meta table
CREATE SEQUENCE seq_attr_at_data_meta START 1024;

-- -----------------------------------------------------------------------------
-- Table: element_data
--
-- Description:	This is the table that contains the name and rules for 
-- 		element fields.   It contains references to the 
--		element table and to the element_container table
--		( parent_id field ).   The place field represents the order
-- 		that this is to be represented with in it's container.
--
--If the element_meta field is set then all the properties are taken from
--	That.    Or maybe not, get feed back on this.
-- 	Define constraint on repeatable and sql_type


CREATE TABLE at_data (
    id              NUMERIC(10,0)   NOT NULL
                                    DEFAULT NEXTVAL('seq_element'),
    element__id  NUMERIC(10,0)   NOT NULL,
    name            VARCHAR(32),
    description     VARCHAR(256),
    place           NUMERIC(10,0)   NOT NULL,
    required        NUMERIC(1,0)    NOT NULL
                                    DEFAULT 0
                                    CONSTRAINT ck_at_data__required
                                      CHECK (required IN (0,1)),
    quantifier      VARCHAR(2),
    autopopulated   NUMERIC(1,0)    NOT NULL
                                    DEFAULT 0
                                      CONSTRAINT ck_at_data__autopopulated
                                      CHECK (autopopulated IN (0,1)),
    active          NUMERIC(1,0)    NOT NULL
                                    DEFAULT 1
                                    CONSTRAINT ck_at_data__active
                                      CHECK (active IN (0,1)),
    map_type__id     NUMERIC(10,0),
    publishable      NUMERIC(1,0)   NOT NULL
                                    DEFAULT 0
                                    CONSTRAINT ck_at_data__publishable
                                      CHECK (publishable IN (0,1)),
    max_length       NUMERIC(10,0),
    sql_type         VARCHAR(30),
    CONSTRAINT pk_at_data__id PRIMARY KEY (id)
);

-- -----------------------------------------------------------------------------
-- Table: attr_element_data
--
-- Description: A table to represent types of attributes.  A type is defined by
--              its subsystem, its element_data ID and an attribute name.

CREATE TABLE attr_at_data (
    id         NUMERIC(10)   NOT NULL
                             DEFAULT NEXTVAL('seq_attr_at_data'),
    subsys     VARCHAR(256)  NOT NULL,
    name       VARCHAR(256)  NOT NULL,
    sql_type   VARCHAR(30)   NOT NULL,
    active     NUMERIC(1)    DEFAULT 1
                             NOT NULL
                             CONSTRAINT ck_attr_at_data__active CHECK (active IN (0,1)),
   CONSTRAINT pk_attr_at_data__id PRIMARY KEY (id)
);

-- -----------------------------------------------------------------------------
-- Table: attr_element_data_val
--
-- Description: A table to hold attribute values.

CREATE TABLE attr_at_data_val (
    id           NUMERIC(10)     NOT NULL
                                 DEFAULT NEXTVAL('seq_attr_at_data_val'),
    object__id   NUMERIC(10)     NOT NULL,
    attr__id     NUMERIC(10)     NOT NULL,
    date_val     TIMESTAMP,
    short_val    VARCHAR(1024),
    blob_val     TEXT,
    serial       NUMERIC(1)      DEFAULT 0,
    active       NUMERIC(1)      DEFAULT 1
                                 NOT NULL
                                 CONSTRAINT ck_attr_at_data_val__active CHECK (active IN (0,1)),
    CONSTRAINT pk_attr_at_data_val__id PRIMARY KEY (id)
);

-- -----------------------------------------------------------------------------
-- Table: attr_element_data_meta
--
-- Description: A table to represent metadata on types of attributes.

CREATE TABLE attr_at_data_meta (
    id        NUMERIC(10)     NOT NULL
                              DEFAULT NEXTVAL('seq_attr_at_data_meta'),
    attr__id  NUMERIC(10)     NOT NULL,
    name      VARCHAR(256)    NOT NULL,
    value     VARCHAR(2048),
    active    NUMERIC(1)      DEFAULT 1
                              NOT NULL
                              CONSTRAINT ck_attr_at_data_meta__active CHECK (active IN (0,1)),
   CONSTRAINT pk_attr_at_data_meta__id PRIMARY KEY (id)
);

-- -----------------------------------------------------------------------------
-- Indexes.
--

CREATE UNIQUE INDEX udx_atd__name__at_id ON at_data(name, element__id);
CREATE INDEX fkx_map_type__atd on at_data(map_type__id);
CREATE INDEX fkx_element__atd on at_data(element__id);

-- Unique index on subsystem/name pair
CREATE UNIQUE INDEX udx_attr_atd__subsys__name ON attr_at_data(subsys, name);

-- Indexes on name and subsys.
CREATE INDEX idx_attr_atd__name ON attr_at_data(LOWER(name));
CREATE INDEX idx_attr_atd__subsys ON attr_at_data(LOWER(subsys));

-- Unique index on object__id/attr__id pair
CREATE UNIQUE INDEX udx_attr_atd_val__obj_attr ON attr_at_data_val (object__id,attr__id);

-- FK indexes on object__id and attr__id.
CREATE INDEX fkx_atd__attr_atd_val ON attr_at_data_val(object__id);
CREATE INDEX fkx_attr_atd__attr_atd_val ON attr_at_data_val(attr__id);

-- Unique index on attr__id/name pair
CREATE UNIQUE INDEX udx_attr_atd_meta__attr_name ON attr_at_data_meta (attr__id, name);

-- Index on meta name.
CREATE INDEX idx_attr_atd_meta__name ON attr_at_data_meta(LOWER(name));

-- FK index on attr__id.
CREATE INDEX fkx_attr_atd__attr_atd_meta ON attr_at_data_meta(attr__id);

/*
Change Log:
$Log: Data.sql,v $
Revision 1.1.1.1  2001/09/06 21:54:01  wheeler
Upload to SourceForge.

*/
