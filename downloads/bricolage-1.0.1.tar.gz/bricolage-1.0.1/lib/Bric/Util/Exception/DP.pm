package Bric::Util::Exception::DP;

=head1 DESCRIPTION

stub package

=cut
