-- Project: Bricolage
-- VERSION: $Revision: 1.2 $
--
-- $Date: 2001/09/17 16:19:43 $
-- Target DBMS: PostgreSQL 7.1.2
-- Author: Michael Soderstrom <miraso@pacbell.net>
--
--
-- This is the SQL representation of the story object
--

-- -----------------------------------------------------------------------------
-- Sequences

-- Unique IDs for the story table
CREATE SEQUENCE seq_story START  1024;

-- Unique IDs for the story_instance table
CREATE SEQUENCE seq_story_instance START 1024;

-- Unique IDs for the story__category mapping table
CREATE SEQUENCE seq_story__category START  1024;

-- Unique ids for the story_contributor table
CREATE SEQUENCE seq_story__contributor START 1024;

-- Unique IDs for the attr_story table
CREATE SEQUENCE seq_attr_story START 1024;

-- Unique IDs for each attr_story_*_val table
CREATE SEQUENCE seq_attr_story_val START 1024;

-- Unique IDs for the story_meta table
CREATE SEQUENCE seq_attr_story_meta START 1024;



-- -----------------------------------------------------------------------------
-- Table story
--
-- Description: The story properties.   Versioning info might get added 
-- 				here and the rights info might get removed.
--
-- 				It is also possible that the asset type field will need
--				a cascading delete.


CREATE TABLE story (
    id                NUMERIC(10,0)   NOT NULL
                                      DEFAULT NEXTVAL('seq_story'),
    priority          NUMERIC(1,0)    NOT NULL
                                      DEFAULT 3
                                      CONSTRAINT ck_story__priority
                                        CHECK (priority BETWEEN 1 AND 5),
    source__id        NUMERIC(10,0)   NOT NULL, 
    usr__id           NUMERIC(10,0),
    element__id    NUMERIC(10,0)   NOT NULL,
    keyword_grp__id   NUMERIC(10,0),
    primary_uri       VARCHAR(128),
    publish_date      TIMESTAMP,
    expire_date       TIMESTAMP,
    cover_date        TIMESTAMP,
    current_version   NUMERIC(10, 0)  NOT NULL,
	workflow__id	  NUMERIC(10,0),
    publish_status    NUMERIC(1,0)    NOT NULL
                                      DEFAULT 0
                                      CONSTRAINT ck_story__publish_status
                                        CHECK (publish_status IN (0,1)),
    active            NUMERIC(1,0)    NOT NULL
                                      DEFAULT 1
                                      CONSTRAINT ck_story__active
                                        CHECK (active IN (0,1)),
    CONSTRAINT pk_story__id PRIMARY KEY (id)
);


-- ----------------------------------------------------------------------------
-- Table story_instance
--
-- Description:  An instance of a story
--

CREATE TABLE story_instance (
    id           NUMERIC(10,0)   NOT NULL
                                 DEFAULT NEXTVAL('seq_story_instance'),
    name         VARCHAR(256),
    description  VARCHAR(1024),
    story__id    NUMERIC(10,0)   NOT NULL,
    version      NUMERIC(10,0),
    usr__id      NUMERIC(10,0)   NOT NULL,
    slug         VARCHAR(64),
    checked_out  NUMERIC(1,0)    NOT NULL
                                 DEFAULT 0
                                 CONSTRAINT ck_story_instance__checked_out
                                   CHECK (checked_out IN (0,1)),
    CONSTRAINT pk_story_instance__id PRIMARY KEY (id)
);
											

-- -----------------------------------------------------------------------------
-- Table story__category
-- 
-- Description: Mapping Table between Stories and categories
--
--

CREATE TABLE story__category (
    id                  NUMERIC(10,0)  NOT NULL
                                       DEFAULT NEXTVAL('seq__story_category'),
    story_instance__id  NUMERIC(10,0)  NOT NULL,
    category__id        NUMERIC(10,0)  NOT NULL,
    main                NUMERIC(1,0)   NOT NULL
                                       DEFAULT 0
                                       CONSTRAINT ck_story__category__main
                                         CHECK (main IN (0,1)),
    CONSTRAINT pk_story_category__id PRIMARY KEY (id)
);

-- -----------------------------------------------------------------------------
-- Table story__contributor
-- 
-- Description: mapping tables between story instances and contributors
--
--

CREATE TABLE story__contributor (
    id                  NUMERIC(10,0)	NOT NULL
                                        DEFAULT NEXTVAL('seq_story__contributor'),
    story_instance__id  NUMERIC(10,0)	NOT NULL,
    member__id          NUMERIC(10,0)	NOT NULL,
    place               NUMERIC(3,0)    NOT NULL,
    role                VARCHAR(256),
    CONSTRAINT pk_story_category_id PRIMARY KEY (id)
);

-- -----------------------------------------------------------------------------
-- Table attr_story
--
-- Description: Attributes for stories
--

CREATE TABLE attr_story (
    id         NUMERIC(10)   NOT NULL
                             DEFAULT NEXTVAL('seq_attr_story'),
    subsys     VARCHAR(256)  NOT NULL,
    name       VARCHAR(256)  NOT NULL,
    sql_type   VARCHAR(30)   NOT NULL,
    active     NUMERIC(1)    DEFAULT 1
                             NOT NULL
                             CONSTRAINT ck_attr_story__active
                               CHECK (active IN (0,1)),
   CONSTRAINT pk_attr_story__id PRIMARY KEY (id)
);

-- -----------------------------------------------------------------------------
-- Table attr_story_val
--
-- Description: Values for the story attributes
-- 
--

CREATE TABLE attr_story_val (
    id           NUMERIC(10)     NOT NULL
                                 DEFAULT NEXTVAL('seq_attr_story_val'),
    object__id   NUMERIC(10)     NOT NULL,
    attr__id     NUMERIC(10)     NOT NULL,
    date_val     TIMESTAMP,
    short_val    VARCHAR(1024),
    blob_val     TEXT,
    serial       NUMERIC(1)      DEFAULT 0,
    active       NUMERIC(1)      DEFAULT 1
                                 NOT NULL
                                 CONSTRAINT ck_attr_story_val__active
                                   CHECK (active IN (0,1)),
    CONSTRAINT pk_attr_story_val__id PRIMARY KEY (id)
);


-- -----------------------------------------------------------------------------
-- Table attr_story_meta
--
-- Description: Meta information on story attributes
--

CREATE TABLE attr_story_meta (
    id        NUMERIC(10)     NOT NULL
                              DEFAULT NEXTVAL('seq_attr_story_meta'),
    attr__id  NUMERIC(10)     NOT NULL,
    name      VARCHAR(256)    NOT NULL,
    value     VARCHAR(2048),
    active    NUMERIC(1)      DEFAULT 1
                              NOT NULL
                              CONSTRAINT ck_attr_story_meta__active
                                CHECK (active IN (0,1)),
   CONSTRAINT pk_attr_story_meta__id PRIMARY KEY (id)
);



-- -----------------------------------------------------------------------------
-- Indexes.
--

-- story
CREATE INDEX idx_story__primary_uri ON story(LOWER(primary_uri));
CREATE INDEX fdx_usr__story ON story(usr__id);
CREATE INDEX fdx_source__story ON story(source__id);
CREATE INDEX fdx_element__story ON story(element__id);
CREATE INDEX fdx_grp__story ON story(keyword_grp__id);

-- story_instance
CREATE INDEX idx_story_instance__name ON story_instance(LOWER(name));
CREATE INDEX idx_story_instance__slug ON story_instance(LOWER(slug));
CREATE INDEX fdx_story__story_instance ON story_instance(story__id);
CREATE INDEX fdx_usr__story_instance ON story_instance(usr__id);

-- story__category
CREATE UNIQUE INDEX udx_story_category__story__cat ON story__category(story_instance__id, category__id);
CREATE INDEX fkx_story__story__category ON story__category(story_instance__id);
CREATE INDEX fkx_category__story__category ON story__category(category__id);

--story__contributor
CREATE INDEX fkx_story__story__contributor ON story__contributor(story_instance__id);
CREATE INDEX fkx_member__story__contributor ON story__contributor(member__id);

-- Unique index on subsystem/name pair
CREATE UNIQUE INDEX udx_attr_story__subsys__name ON attr_story(subsys, name);

-- Indexes on name and subsys.
CREATE INDEX idx_attr_story__name ON attr_story(LOWER(name));
CREATE INDEX idx_attr_story__subsys ON attr_story(LOWER(subsys));

-- Unique index on object__id/attr__id pair
CREATE UNIQUE INDEX udx_attr_story_val__obj_attr ON attr_story_val (object__id,attr__id);

-- FK indexes on object__id and attr__id.
CREATE INDEX fkx_story__attr_story_val ON attr_story_val(object__id);
CREATE INDEX fkx_attr_story__attr_story_val ON attr_story_val(attr__id);

-- Unique index on attr__id/name pair
CREATE UNIQUE INDEX udx_attr_story_meta__attr_name ON attr_story_meta (attr__id, name);

-- Index on meta name.
CREATE INDEX idx_attr_story_meta__name ON attr_story_meta(LOWER(name));

-- FK index on attr__id.
CREATE INDEX fkx_attr_story__attr_story_meta ON attr_story_meta(attr__id);


/*
Change Log:
$Log: Story.sql,v $
Revision 1.2  2001/09/17 16:19:43  wheeler
Corrected spelling of "contributor" but grepping through files and fixing them,
plus deleting some files, renaming them, and then adding them back in.

Revision 1.1.1.1  2001/09/06 21:53:51  wheeler
Upload to SourceForge.

*/
