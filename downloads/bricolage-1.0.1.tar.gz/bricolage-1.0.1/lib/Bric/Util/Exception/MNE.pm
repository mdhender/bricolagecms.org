package Bric::Util::Exception::MNE;

=head1 DESCRIPTION

stub package

=cut
