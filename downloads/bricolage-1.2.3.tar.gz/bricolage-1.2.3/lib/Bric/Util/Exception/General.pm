package Bric::Util::Exception::General;

=head1 DESCRIPTION

stub package

=cut







