-- Project: Bricolage
-- VERSION: $Revision: 1.4 $
--
-- $Date: 2001/12/04 18:17:47 $
-- Target DBMS: PostgreSQL 7.1.2
-- Author: David Wheeler <david@wheeler.net>

-- 
-- TABLE: event_member
--


