package Bric::Util::Grp::Keyword;
###############################################################################

=head1 NAME

Bric::Util::Grp::Keyword - A class to impliment keyword synonyms over groups.

=head1 VERSION

$Revision: 1.1.1.1 $

=cut

our $VERSION = substr(q$Revision: 1.1.1.1 $, 10, -1);

=head1 DATE

$Date: 2001/09/06 21:55:56 $

=head1 SYNOPSIS

 use Bric::Util::Grp::Keyword;

 # Create a new keyword synonym object.
 my $syn  = new Bric::Util::Grp::Keyword();

 # Add a description for this synonym group.
 $desc    = $syn->get_description($desc);

 # Add a keyword to this synonym group.
 $success = $syn->add_synonym(@kw);

 # Remove a keyword from this synonym group.
 $success = $syn->del_synonym($kw_id || $kw);

 # Return all keywords that are in this synonym group.
 @kw      = $syn->all_synonyms();

=head1 DESCRIPTION

This is the keyword synonym interface as implimented using the group structure.

=cut

#==============================================================================#
# Dependencies                         #
#======================================#

#--------------------------------------#
# Standard Dependencies                 

use strict;

#--------------------------------------#
# Programatic Dependencies              
 


#==============================================================================#
# Inheritance                          #
#======================================#

use base qw( Bric::Util::Grp );

#=============================================================================#
# Function Prototypes                  #
#======================================#



#==============================================================================#
# Constants                            #
#======================================#

use constant PACKAGE => 'Bric::Biz::Keyword';

#==============================================================================#
# Fields                               #
#======================================#

#--------------------------------------#
# Public Class Fields                   



#--------------------------------------#
# Private Class Fields                  



#--------------------------------------#
# Instance Fields                       

# This method of Bricolage will call 'use fields' for you and set some permissions.
BEGIN {
    Bric::register_fields({
			 # Public Fields

			 # Private Fields
			 
			});
}

#==============================================================================#

=head1 INTERFACE

=head2 Constructors

=over 4

=cut

#--------------------------------------#
# Constructors                          

#------------------------------------------------------------------------------#

=item $obj = new Bric::Util::Grp::Keyword($init);

Creates a new keyword synonym group.  Uses inherited 'new' method.

B<Throws:>

NONE

B<Side Effects:>

NONE

B<Notes:>

NONE

=cut

#------------------------------------------------------------------------------#

=item @objs = lookup Bric::Util::Grp::Keyword($param);

Uses inherited 'lookup' method.

B<Throws:>

NONE

B<Side Effects:>

NONE

B<Notes:>

NONE

=cut

#------------------------------------------------------------------------------#

=item @objs = list Bric::Util::Grp::Keyword($param);

Uses inherited 'list' method.

B<Throws:>

NONE

B<Side Effects:>

NONE

B<Notes:>

NONE

=cut

#--------------------------------------#

=head2 Destructors

=cut

sub DESTROY {
    # This method should be here even if its empty so that we don't waste time
    # making Bricolage's autoload method try to find it.
}

#--------------------------------------#

=head2 Public Class Methods

=cut

#--------------------------------------#

=head2 Public Instance Methods

=cut

#------------------------------------------------------------------------------#

=item $class_id = Bric::Util::Grp::Category->get_class_id()

This will return the class id that this group is associated with
it should have an id that maps to the class object instance that is
associated with the class of the grp ie Bric::Util::Grp::AssetVersion

B<Throws:>
NONE

B<Side Effects:>
NONE

B<Notes:>

Overwite this in your sub classes

=cut

sub get_class_id {
    return 27;
}

#------------------------------------------------------------------------------#

=item $h = $key->get_supported_classes;

This supplies a package to table name mapping.

B<Throws:>

NONE

B<Side Effects:>

NONE

B<Notes:>

NONE

=cut

sub get_supported_classes {
    return { &PACKAGE => 'keyword' };
}	

#------------------------------------------------------------------------------#

=item $success = $syn->add_synonym([$kw_obj || $kw_id]);

Add a synonym.

B<Throws:>

NONE

B<Side Effects:>

NONE

B<Notes:>

NONE

=cut

sub add_synonym {
    my Bric::Util::Grp::Keyword $self = shift;
    my ($kw) = @_;

    unless (ref $kw) {
	# HACK: This should throw an error object.
	die __PACKAGE__.":add_synonym - Bad arguments\n";
    }

    my @mem = map {ref($_) ? {'obj'=>$_} 
                           : {'type' => PACKAGE, 'id' => $kw} } @$kw;

    # Add the objects.
    $self->add_members(\@mem);

    return $self;
}

#------------------------------------------------------------------------------#

=item $success = $syn->del_synonym([$kw_obj || $kw_id]);

Remove a keyword from this synonym group.

B<Throws:>

NONE

B<Side Effects:>

NONE

B<Notes:>

NONE

=cut

sub del_synonym {
    my Bric::Util::Grp::Keyword $self = shift;
    my ($kw) = @_;

    unless (ref $kw) {
	# HACK: This should throw an error object.
	die __PACKAGE__.":add_synonym - Bad arguments\n";
    }

    my @mem = map {ref($_) ? {'obj'=>$_} 
		           : {'type' => PACKAGE, 'id' => $kw} } @$kw;

    # Add the objects.
    $self->delete_member(\@mem);

    return $self;
}

#------------------------------------------------------------------------------#

=item @kw = $syn->all_synonyms();

Return all keywords that are in this synonym group.

B<Throws:>

NONE

B<Side Effects:>

NONE

B<Notes:>

NONE

=cut

sub all_synonyms {
    my Bric::Util::Grp::Keyword $self = shift;
    my @mem = $self->get_members();
    my @syn = map { $_->get_object } @mem;
    
    return wantarray ? @syn : \@syn;
}

#==============================================================================#

=head2 Private Methods

=cut

#--------------------------------------#

=head2 Private Class Methods

NONE

=cut


# Add methods here that do not require an object be instantiated, and should not
# be called outside this module (e.g. utility functions for class methods).
# Use same POD comment style as above for 'new'.

#--------------------------------------#

=head2 Private Instance Methods

NONE

=cut

# Add methods here that apply to an instantiated object, but should not be 
# called directly (e.g. utility functions for instance methods).
# Use same POD comment style as above for 'new'.

1;
__END__

=back

=head1 NOTES

This module is the group implimentation of keyword synonyms.  All functionality
needed for keyword synonyms is implimented here and used by Bric::Biz::Keyword which 
represents the front end interface.

=head1 AUTHOR

"Garth Webb" <garth@perijove.com>
Bricolage Engineering

=head1 SEE ALSO

L<perl>, L<Bric>, L<Bric::Biz::Keyword>

=head1 REVISION HISTORY

$Log: Keyword.pm,v $
Revision 1.1.1.1  2001/09/06 21:55:56  wheeler
Upload to SourceForge.

=cut
